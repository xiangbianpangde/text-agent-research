# CURRENT — 当前研究认知

## 长上下文（128K）性能对比

**当前结论（2026-08-20）**：R051（模型 A）因数据泄漏被标记 invalid。128K 场景下 A/B 比较的证据不足，结论状态：needs_review。

<!-- sources: organized/EXP-017/result.md -->