# REPORT-001 — 长上下文性能对比（基线）

> 冻结时间：2026-08-01（阶段 1）
> 状态：历史快照，禁止自动重写

## 结论

在 128K 长上下文场景下，模型 A 整体优于模型 B（accuracy 72.3% vs 68.1%）。

<!-- sources: organized/EXP-017/result.md@a61cf218 -->