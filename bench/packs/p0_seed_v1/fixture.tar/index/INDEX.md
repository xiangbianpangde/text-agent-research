# INDEX — 导航层（可重建，不是证据）

## EXP-017 长上下文性能对比

- 状态：needs_review
- 整理文件：organized/EXP-017/result.md、organized/EXP-017/analysis.md
- Raw：raw/EXP-017/R051/（invalid）、raw/EXP-017/R052/、raw/EXP-017/R053/
- 关联汇报：REPORT-001、REPORT-002、REPORT-003