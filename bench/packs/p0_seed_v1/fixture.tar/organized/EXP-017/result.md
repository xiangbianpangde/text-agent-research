---
id: ORG-EXP017
experiment: EXP-017
version: 3
sources:
  - path: raw/EXP-017/R051/
    source_type: directory
    content_hash: "sha256:ab4db737d50f0d9d023ec01915f295e92497a3a518c9e7a7de38805ab2d3e3ae"
    reference_scope: historical
    git_commit: "2bebbd9cb3ab817c71e0cc30683ad1dc2533eab4"
  - path: raw/EXP-017/R052/
    source_type: directory
    content_hash: "sha256:b5878d5bfb2251f8ad4f8748a388970456beed4f6229e6274e6c5d7a32aed175"
    reference_scope: historical
    git_commit: "ddee7b5bac65b26d63505aec8c2b570d14c72d4d"
  - path: raw/EXP-017/R053/
    source_type: directory
    content_hash: "sha256:451b451681d9c5095124d2cf9c8c140fcd10165eaf0d185090444240fccec0c6"
    reference_scope: historical
    git_commit: "ddee7b5bac65b26d63505aec8c2b570d14c72d4d"
---

# EXP-017 结果（复审）

## 长上下文（128K）

R051（模型 A，128K）因数据泄漏被标记 invalid，从证据中排除。

| run | model | context | accuracy | 状态 |
|---|---|---|---|---|
| R051 | A | 128K | 72.3% | invalid（排除） |
| R052 | B | 128K | 70.1% | 有效 |
| R053 | A | 64K | 74.2% | 对照（不同场景） |

## 结论（复审）

排除 R051 后，128K 场景仅剩模型 B 有效观测，无法比较 A/B。结论需重新实验，状态为 needs_review。