---
id: ORG-EXP017-analysis
experiment: EXP-017
version: 1
sources:
  - path: raw/EXP-017/R051/
    source_type: directory
    content_hash: "sha256:9d191aca1a49000871dea376bf1575389bd656e1ce2b62bc85bc2e4121e8e13e"
    reference_scope: historical
    git_commit: "ddee7b5bac65b26d63505aec8c2b570d14c72d4d"
  - path: raw/EXP-017/R052/
    source_type: directory
    content_hash: "sha256:b5878d5bfb2251f8ad4f8748a388970456beed4f6229e6274e6c5d7a32aed175"
    reference_scope: historical
    git_commit: "ddee7b5bac65b26d63505aec8c2b570d14c72d4d"
  - path: raw/EXP-017/R053/
    source_type: directory
    content_hash: "sha256:451b451681d9c5095124d2cf9c8c140fcd10165eaf0d185090444240fccec0c6"
    reference_scope: historical
    git_commit: "ddee7b5bac65b26d63505aec8c2b570d14c72d4d"
---

# EXP-017 分析（baseline）

## 观察

- R051：模型 A，128K，accuracy 72.3%
- R052：模型 B，128K，accuracy 68.1%
- R053：模型 A，64K 对照，accuracy 74.2%

## 初步推断

长上下文（128K）下 A 领先 B 约 4 个百分点。64K 对照下 A 表现更高，但属于不同场景，不直接比较。
