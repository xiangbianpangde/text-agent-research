# fixture — 合成测试项目（P0-A）

> **本目录只包含合成数据。**
> 不引用任何真实 R-ICL 数据；不代表生产研究状态；不得将本目录结果描述为科学结论。

用途：验证 P0-B 只读检索与 P0-C 完整性检测（验收 A–H、故障注入 F01–F10）。

结构（见 `P0-Contract.md` §12）：

```text
reports/       CURRENT.md + CURRENT.sources.yaml + history/REPORT-NNN
index/         INDEX.md（导航层，可重建）
organized/     L1 整理文件
raw/           L0 原始材料（合成）
experiments/   最小只读 ExperimentSpec
runs/          最小只读 RunManifest
tasks/         P0 占位
events/        P1 启用；P0 不实现事件机制
.index/        SQLite 派生索引（P0-B 启动时构建，不入 Git）
```

阶段构造（对应 `P0-Contract.md` §9）：

```text
阶段 1   Raw A/B → Organized result.md (baseline) → REPORT-001
阶段 2   Organized 更新 → CURRENT 改变 → REPORT-002
阶段 3   Raw A 标记 invalid → CURRENT 再改变 → REPORT-003
```

每阶段两个 commit：内容 commit（raw/organized/experiments/runs/index）→ 冻结 commit（reports）。
